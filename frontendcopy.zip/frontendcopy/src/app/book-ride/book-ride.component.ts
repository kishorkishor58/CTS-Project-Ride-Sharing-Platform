import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BookingsService } from '../service/bookings.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-book-ride',
  templateUrl: './book-ride.component.html',
  styleUrl: './book-ride.component.css'
})
export class BookRideComponent implements OnInit{

  bookRideScheduleForm!:FormGroup;
  bookingsId:number=0;
  today:Date;

  constructor(private route:ActivatedRoute,private http:HttpClient,private bookingsService:BookingsService,private formBuilder:FormBuilder){

    this.today=new Date();
  }
  ngOnInit() {

    this.bookRideScheduleForm = this.formBuilder.group({
    'bookedOn' : new FormControl(null,Validators.required),
    'riderUserId' : new FormControl(null,[Validators.required,Validators.min(100),Validators.max(999),this.nonNegative]),
    'noOfSeats' : new FormControl(null,[Validators.required,Validators.min(1),Validators.max(2),this.nonNegative]),
    'totalAmount' : new FormControl(null,[Validators.required,Validators.min(0),Validators.max(9999),this.nonNegative]),
    'paymentMode' : new FormControl(null),
    'rideSchedulesId' : new FormControl(this.route.snapshot.params['id'])
    });
    
  }

  onBook(){
  
    this.bookingsService.createBookings(this.bookRideScheduleForm.value).subscribe({
      next: responseData => {
        this.bookingsId=responseData;
        this.bookRideScheduleForm.reset();
      }
  });
}

nonNegative(control: AbstractControl) {
  if (control.value < 0) {
    return { 'negative': true };
  }
  return null;
}

}
