export class Distances {
    distanceId: number;
    from: string;
    to: string;
    distanceInKMS: number;
}
