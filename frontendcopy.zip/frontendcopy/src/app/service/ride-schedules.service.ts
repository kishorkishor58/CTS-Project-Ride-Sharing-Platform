import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RideSchedules } from '../model/ride-schedules';
import { FormGroup, NgForm } from '@angular/forms';
import { FareParameters } from '../model/fare-parameters';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RideSchedulesService {
  
  constructor(private http:HttpClient) { }

  private addRideScheduleURL='http://localhost:8090/api/rides/schedule';
  private retrieveCalculatedFareURL='http://localhost:8090/api/rides/calculatefare';
  private searchRideScheduleURL="http://localhost:8090/api/rides/search"

  public createRideSchedule(rideSchedule: RideSchedules){
    return this.http.post<RideSchedules>(this.addRideScheduleURL,rideSchedule);
  }

  public getCalculatedFare(fareParameters: FareParameters){
    return this.http.post<number>(this.retrieveCalculatedFareURL, fareParameters);
  }
  public getSearchRideSchedule(to: string, from: string, minPrice: number, maxPrice: number, availableSeats: number): Observable<RideSchedules[]> {
    const url = `${this.searchRideScheduleURL}?from=${from}&to=${to}&minPrice=${minPrice}&maxPrice=${maxPrice}&availableSeats=${availableSeats}`;
    return this.http.get<RideSchedules[]>(url);
  }
}
