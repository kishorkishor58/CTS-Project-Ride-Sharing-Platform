package com.cognizant.authentication.controller;

import com.cognizant.authentication.dto.UserDTO;
import com.cognizant.authentication.dto.UserRequestDTO;
import com.cognizant.authentication.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/authenticate")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthenticationController{

    @Autowired
    private UserService userService;

    @PostMapping("users")
    public ResponseEntity<?> authenticate(@RequestBody UserRequestDTO userRequestDTO){

        System.out.println("UserRequestDTO:"+userRequestDTO);
        UserDTO userDTO=userService.authenticateUser(userRequestDTO.getUserName(), userRequestDTO.getPassword());
        System.out.println("UserDTO:"+userDTO);
        if(userDTO.getUserName()!=null) {
            return new ResponseEntity<UserDTO>(userDTO, HttpStatus.ACCEPTED);
        }else {
            return new ResponseEntity<>("Invalid username and password",HttpStatus.FORBIDDEN);
        }

    }


}
