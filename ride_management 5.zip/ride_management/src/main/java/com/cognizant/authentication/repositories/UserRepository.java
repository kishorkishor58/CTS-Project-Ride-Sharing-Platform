package com.cognizant.authentication.repositories;

import com.cognizant.authentication.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<Users,String> {

}
