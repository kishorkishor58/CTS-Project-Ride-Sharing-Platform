package com.cognizant.controller;

import com.cognizant.dto.BookingsDTO;
import com.cognizant.service.BookingsService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import lombok.extern.slf4j.XSlf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@CrossOrigin("*")
@RestController
@RequestMapping("/api/rides")
public class BookingsController {
    @Autowired
    BookingsService bookingsService;

    @Operation(description = "Get Booking Id")
    @PostMapping("/book")
    public ResponseEntity<?> getBookingId(@Valid @RequestBody BookingsDTO bookingsDTO){
        BookingsDTO bDTO = bookingsService.insertBookings(bookingsDTO);
        log.info("successfully retrieved booking id");
        return new ResponseEntity<>(bDTO.getId(), HttpStatus.OK);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidationExceptions(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        List<String> errorMessages = bindingResult.getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .toList();
        return new ResponseEntity<>(errorMessages, HttpStatus.BAD_REQUEST);
    }


}
