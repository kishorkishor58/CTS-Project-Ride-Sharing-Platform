package com.cognizant.controller;

import com.cognizant.exception.NoOfSeatsLimitExceedException;
import com.cognizant.exception.SameFromAndToPlaceException;
import com.cognizant.dto.FareParametersDTO;
import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.exception.VehicleNotApprovedException;
import com.cognizant.service.RideSchedulesService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.util.List;

import org.springframework.context.support.DefaultMessageSourceResolvable;

@Slf4j
@CrossOrigin("*")
@RestController
@RequestMapping(value = "/api/rides")
public class RideSchedulesController {

    @Autowired
    RideSchedulesService rideSchedulesService;


    @PostMapping(value = "/schedule")
    public ResponseEntity<?> createNewRide(@Valid @RequestBody RideSchedulesDTO rideSchedulesDTO){

        try{
            RideSchedulesDTO rd= rideSchedulesService.insertRideSchedules(rideSchedulesDTO);
            log.info("successfully created a new ride");
            return new ResponseEntity<>(rd, HttpStatus.OK);
        }catch (SameFromAndToPlaceException | VehicleNotApprovedException | NoOfSeatsLimitExceedException e){
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }
    @PostMapping(value = "/calculatefare")
    public int calculateFare(@RequestBody FareParametersDTO fareParametersDTO){

        int fare = rideSchedulesService.calculateFare(fareParametersDTO);
        log.info("successfully calculated the fare");
        return fare;

    }

    @Operation(description = "Searching the ride schedules")
    @GetMapping("/search")
    public List<RideSchedulesDTO> searchRide(@PathVariable @RequestParam("to") String to,@RequestParam("from") String from,@RequestParam("minPrice") int minPrice,@RequestParam("maxPrice")int maxPrice,@RequestParam("availableSeats")int availableSeats){
        SearchCriteriaDTO searchCriteriaDTO=new SearchCriteriaDTO();
        searchCriteriaDTO.setTo(to);
        searchCriteriaDTO.setFrom(from);
        searchCriteriaDTO.setMaxPrice(maxPrice);
        searchCriteriaDTO.setMinPrice(minPrice);
        searchCriteriaDTO.setAvailableSeats(availableSeats);

        log.info("successfully implemented search ride schedule");
        return rideSchedulesService.searchRide(searchCriteriaDTO);

    }



    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidationExceptions(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        List<String> errorMessages = bindingResult.getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .toList();
        return new ResponseEntity<>(errorMessages, HttpStatus.BAD_REQUEST);
    }

}
