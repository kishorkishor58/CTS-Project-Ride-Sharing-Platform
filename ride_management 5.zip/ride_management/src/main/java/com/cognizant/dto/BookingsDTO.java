package com.cognizant.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.validator.constraints.Range;
import java.time.LocalDate;

@Setter
@Getter
public class BookingsDTO {
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int id;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private LocalDate bookedOn;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private Integer riderUserId;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	@Range(min=1,max=2 , message = "{com.cognizant.dto.BookingsDTO.noOfSeats.value}")
	private Integer noOfSeats;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private Integer totalAmount;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String paymentMode;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private Integer rideSchedulesId;


}
