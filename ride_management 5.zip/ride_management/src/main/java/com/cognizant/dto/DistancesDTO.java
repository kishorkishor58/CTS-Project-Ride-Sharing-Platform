package com.cognizant.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;


@Setter
@Getter
public class DistancesDTO {
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private int id;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String from;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String to;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private Integer distanceInKMS;


}
