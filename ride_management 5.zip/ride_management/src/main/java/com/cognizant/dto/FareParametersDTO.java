package com.cognizant.dto;

import lombok.*;
import org.springframework.stereotype.Component;
@Setter
@Getter
@Component
public class FareParametersDTO {

	private int distance;
	private String vehicleRegistrationNo;

}
