package com.cognizant.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
public class RideSchedulesDTO {

	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String isApproved;

	private int id;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String rideFrom;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String rideTo;

	@FutureOrPresent(message = "{com.cognizant.dto.FutureOrPresent.error}")
	private LocalDate rideStartsOn;

	@FutureOrPresent(message = "{com.cognizant.dto.FutureOrPresent.error}")
	private LocalTime rideTime;

	private Integer rideFare;

	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	@Size(min = 10,max = 10,message = "{com.cognizant.dto.RideSchedulesDTO.vehicleRegistrationNo.length}")
	private String vehicleRegistrationNo;

	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private Integer motoristUserId;

	private Integer noOfSeatsAvailable;

}
