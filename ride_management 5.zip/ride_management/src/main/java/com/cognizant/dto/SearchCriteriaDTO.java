package com.cognizant.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
public class SearchCriteriaDTO {

	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String from;
	@NotBlank(message = "{com.cognizant.dto.NotBlank.error}")
	private String to;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private Integer minPrice;
	@NotNull(message = "{com.cognizant.dto.NotNull.error}")
	private Integer maxPrice;
	private Integer availableSeats;



}
