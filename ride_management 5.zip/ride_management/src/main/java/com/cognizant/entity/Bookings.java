package com.cognizant.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "Bookings")
public class Bookings {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Bookings_Id")
	private int bookingid;
	@Column(name = "Booked_On")
	private LocalDate bookedOn;
	@Column(name = "Rider_User_Id")
	private int riderUserId;
	@Column(name = "No_Of_Seats")
	private int noOfSeats;
	@Column(name = "Total_Amount")
	private int totalAmount;
	@Column(name = "Payment_Mode")
	private String paymentMode;

	@ManyToOne
	@JoinColumn(name = "Ride_Schedules_Id")
	private RideSchedules rideSchedules;

}
