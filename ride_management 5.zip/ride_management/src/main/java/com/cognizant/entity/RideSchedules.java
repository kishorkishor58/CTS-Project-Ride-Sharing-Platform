package com.cognizant.entity;

import java.time.LocalDate;
import java.time.LocalTime;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Getter
@Setter
@Entity
@Table(name = "Ride_Schedules")
public class RideSchedules {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Ride_Schedules_Id")
	private int id;
	@Column(name = "Ride_From")
	private String rideFrom;
	@Column(name = "Ride_To")
	private String rideTo;
	@Column(name = "Ride_Starts_On")
	private LocalDate rideStartsOn;
	@Column(name = "Ride_Time")
	private LocalTime rideTime;
	@Column(name = "Ride_Fare")
	private int rideFare;
	@Column(name = "Vehicle_Registration_No")
	private String vehicleRegistrationNo;
	@Column(name = "Motorist_User_Id")
	private int motoristUserId;
	@Column(name = "No_Of_Seats_Available")
	private int noOfSeatsAvailable;



}
