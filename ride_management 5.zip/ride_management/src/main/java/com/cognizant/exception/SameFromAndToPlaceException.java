package com.cognizant.exception;

public class SameFromAndToPlaceException extends RuntimeException{
    public SameFromAndToPlaceException(String message) {

        super(message);
    }
}
