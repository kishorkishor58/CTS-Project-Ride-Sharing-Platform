package com.cognizant.mapper;


import com.cognizant.repositories.DistancesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.FareParametersDTO;
import com.cognizant.entity.Distances;
import com.cognizant.entity.RideSchedules;

@Service
public class FareParametersMapper {

	@Autowired
	private DistancesRepository distancesRepository;
	public FareParametersDTO toFareParametersdto(int distanceId,RideSchedules rs) {

		Distances distances = distancesRepository.findById(distanceId).get();
		FareParametersDTO fpdto = new FareParametersDTO();

		fpdto.setDistance(distances.getDistanceInKMS());
		fpdto.setVehicleRegistrationNo(rs.getVehicleRegistrationNo());
		return fpdto;
	}

}
