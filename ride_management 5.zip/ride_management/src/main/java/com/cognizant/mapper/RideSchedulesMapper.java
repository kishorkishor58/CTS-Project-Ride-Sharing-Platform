package com.cognizant.mapper;

import org.springframework.stereotype.Service;

import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.entity.RideSchedules;

@Service
public class RideSchedulesMapper {
	
	public RideSchedulesDTO toRideSchedulesDTO(RideSchedules rs) {
		RideSchedulesDTO rideSchedulesdto = new RideSchedulesDTO();
		
		rideSchedulesdto.setId(rs.getId());
		rideSchedulesdto.setRideFrom(rs.getRideFrom());
		rideSchedulesdto.setRideTo(rs.getRideTo());
		rideSchedulesdto.setRideStartsOn(rs.getRideStartsOn());
		rideSchedulesdto.setRideTime(rs.getRideTime());
		rideSchedulesdto.setRideFare(rs.getRideFare());
		rideSchedulesdto.setVehicleRegistrationNo(rs.getVehicleRegistrationNo());
		rideSchedulesdto.setMotoristUserId(rs.getMotoristUserId());
		rideSchedulesdto.setNoOfSeatsAvailable(rs.getNoOfSeatsAvailable());

		return rideSchedulesdto;
	}
	
	
	public RideSchedules toRideSchedules(RideSchedulesDTO rsdto) {
		RideSchedules rideSchedules = new RideSchedules();
		
		rideSchedules.setId(rsdto.getId());
		rideSchedules.setRideFrom(rsdto.getRideFrom());
		rideSchedules.setRideTo(rsdto.getRideTo());
		rideSchedules.setRideStartsOn(rsdto.getRideStartsOn());
		rideSchedules.setRideTime(rsdto.getRideTime());
		rideSchedules.setRideFare(rsdto.getRideFare());
		rideSchedules.setVehicleRegistrationNo(rsdto.getVehicleRegistrationNo());
		rideSchedules.setMotoristUserId(rsdto.getMotoristUserId());
		rideSchedules.setNoOfSeatsAvailable(rsdto.getNoOfSeatsAvailable());

		return rideSchedules;
	}

}
