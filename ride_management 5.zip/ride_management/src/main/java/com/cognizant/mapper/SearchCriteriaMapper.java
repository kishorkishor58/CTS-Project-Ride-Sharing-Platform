package com.cognizant.mapper;

import com.cognizant.entity.RideSchedules;
import org.springframework.stereotype.Service;

import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.entity.Distances;

@Service
public class SearchCriteriaMapper {
	public SearchCriteriaDTO toSearchParamterdto(Distances distances, RideSchedules rs) {

		SearchCriteriaDTO scdto = new SearchCriteriaDTO();

		scdto.setFrom(distances.getFrom());
		scdto.setTo(distances.getTo());
		scdto.setAvailableSeats(rs.getNoOfSeatsAvailable());

		return scdto;

	}

}
