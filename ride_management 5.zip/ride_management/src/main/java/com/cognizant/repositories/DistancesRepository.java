package com.cognizant.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Distances;


@Repository
public interface DistancesRepository extends JpaRepository<Distances, Integer>{

    Distances findByFromAndTo(String from, String to);

}
