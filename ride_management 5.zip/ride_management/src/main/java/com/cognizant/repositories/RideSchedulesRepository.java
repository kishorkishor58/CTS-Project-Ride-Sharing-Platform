package com.cognizant.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.RideSchedules;

import java.util.ArrayList;

@Repository
public interface RideSchedulesRepository extends JpaRepository<RideSchedules, Integer> {
    ArrayList<RideSchedules> findByRideFromAndRideTo(String rideFrom,String rideTo);

}

