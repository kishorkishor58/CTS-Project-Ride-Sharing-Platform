package com.cognizant.service;

import com.cognizant.dto.BookingsDTO;

public interface BookingsService {
	BookingsDTO insertBookings(BookingsDTO bookingsdto);

}
