package com.cognizant.service.impl;

import com.cognizant.service.BookingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.BookingsDTO;
import com.cognizant.entity.Bookings;
import com.cognizant.mapper.BookingsMapper;
import com.cognizant.repositories.BookingsRepository;

@Service
public class BookingsServiceImpl implements BookingsService {
	
	@Autowired
	private BookingsMapper bMapper;
	
	@Autowired
	private BookingsRepository bRepository;

	@Override
	public BookingsDTO insertBookings(BookingsDTO bookingsdto) {

		Bookings bookings = bMapper.toBookings(bookingsdto);

		Bookings createBooking = bRepository.save(bookings);
		
		return bMapper.toBookingsdto(createBooking);
		
	}

}
