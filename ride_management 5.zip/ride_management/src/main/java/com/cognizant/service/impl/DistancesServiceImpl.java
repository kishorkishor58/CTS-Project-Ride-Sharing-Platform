package com.cognizant.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.service.DistancesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.DistancesDTO;
import com.cognizant.entity.Distances;
import com.cognizant.mapper.DistanceMapper;
import com.cognizant.repositories.DistancesRepository;

@Service
public class DistancesServiceImpl implements DistancesService {
	
	@Autowired
	private DistanceMapper distanceMapper;
	@Autowired
	private DistancesRepository distancesRepository;

	@Override
	public List<DistancesDTO> getAllDistance() {
		
		List<Distances> distances = distancesRepository.findAll();
		List<DistancesDTO> distancedto = new ArrayList<>();
		for(Distances d : distances) {
			DistancesDTO disDto = distanceMapper.toDistanceDTO(d);
			distancedto.add(disDto);
		}
		return distancedto;
	}



}
