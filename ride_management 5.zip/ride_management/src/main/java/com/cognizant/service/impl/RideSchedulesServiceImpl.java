package com.cognizant.service.impl;

import com.cognizant.exception.NoOfSeatsLimitExceedException;
import com.cognizant.exception.SameFromAndToPlaceException;
import com.cognizant.dto.FareParametersDTO;
import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.entity.Distances;
import com.cognizant.exception.VehicleNotApprovedException;
import com.cognizant.repositories.DistancesRepository;
import com.cognizant.service.RideSchedulesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.entity.RideSchedules;
import com.cognizant.mapper.RideSchedulesMapper;
import com.cognizant.repositories.RideSchedulesRepository;

import java.util.*;

@Service
public class RideSchedulesServiceImpl implements RideSchedulesService {

	@Autowired
	private DistancesRepository distancesRepository;

	@Autowired
	private RideSchedulesRepository rideSchedulesRepository;

	@Autowired
	private RideSchedulesMapper rsMapper;

	@Autowired
	private FareParametersDTO fareParameters;


	@Override
	public RideSchedulesDTO insertRideSchedules(RideSchedulesDTO rideSchedulesdto) throws VehicleNotApprovedException,SameFromAndToPlaceException,NoOfSeatsLimitExceedException{

		if(rideSchedulesdto.getIsApproved().equals("rejected")){
			throw new VehicleNotApprovedException("Vehicle was not Approved by the security head");
		}

		Distances distances = distancesRepository.findByFromAndTo(rideSchedulesdto.getRideFrom(), rideSchedulesdto.getRideTo());

		//convert the Dto object to entity
		RideSchedules rideSchedule = rsMapper.toRideSchedules(rideSchedulesdto);

		if(rideSchedulesdto.getRideFrom().equalsIgnoreCase(rideSchedulesdto.getRideTo())){
			throw new SameFromAndToPlaceException("From place and To place Should not be same");
		}

		int maxNoOfSeats=4;
		if(rideSchedulesdto.getNoOfSeatsAvailable()>maxNoOfSeats){
			throw new NoOfSeatsLimitExceedException("The number of seats in a ride exceeded the limit");
		}

		fareParameters.setDistance(distances.getDistanceInKMS());

		// create a new Ride Schedule object
		RideSchedules createRideSchedule = rideSchedulesRepository.save(rideSchedule);

		//now convert the entity object to dto and return it
	 	 RideSchedulesDTO rideDTO = rsMapper.toRideSchedulesDTO(createRideSchedule);
		  rideDTO.setIsApproved(rideSchedulesdto.getIsApproved());
		 return rideDTO;
	}

	@Override
	public List<RideSchedulesDTO> searchRide(SearchCriteriaDTO searchCriteriaDTO) {

		ArrayList<RideSchedules> rideSchedulesArrayList = rideSchedulesRepository.findByRideFromAndRideTo(searchCriteriaDTO.getFrom(), searchCriteriaDTO.getTo());
		List<RideSchedulesDTO> rideSchedulesDTOList = new ArrayList<>();
		for(RideSchedules rideSchedules:rideSchedulesArrayList){
			if (rideSchedules.getRideFare() >= searchCriteriaDTO.getMinPrice() && rideSchedules.getRideFare() <= searchCriteriaDTO.getMaxPrice() && rideSchedules.getNoOfSeatsAvailable()>= searchCriteriaDTO.getAvailableSeats()) {
				RideSchedulesDTO rideSchedulesDTO=rsMapper.toRideSchedulesDTO(rideSchedules);
				rideSchedulesDTOList.add(rideSchedulesDTO);
			}
		}
		return rideSchedulesDTOList;
	}


	@Override
	public int calculateFare(FareParametersDTO fareParametersDTO) {
		int farePerKm=10;
		int distance= fareParametersDTO.getDistance();
		return  farePerKm * distance;
	}




}



