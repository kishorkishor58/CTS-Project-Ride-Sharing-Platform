INSERT INTO Distances (From_Place, To_Place, Distance_In_KMS) VALUES
('Kannur', 'Taliparamba', 24),
('Kannur', 'Kozhikode', 36),
('Kannur', 'Payyannur', 48),
('Kannur', 'Kasargode', 57),
('Taliparamba', 'Kannur', 68),
('Taliparamba', 'Kozhikode', 79),
('Taliparamba', 'Payyannur', 85),
('Taliparamba', 'Kasargode', 92),
('Kozhikode', 'Kannur', 73),
('Kozhikode', 'Taliparamba', 64),
('Kozhikode', 'Payyannur', 55),
('Kozhikode', 'Kasargode', 46),
('Payyannur', 'Kannur', 37),
('Payyannur', 'Taliparamba', 28),
('Payyannur', 'Kozhikode', 19),
('Payyannur', 'Kasargode', 11),
('Kasargode', 'Kannur', 22),
('Kasargode', 'Taliparamba', 33),
('Kasargode', 'Kozhikode', 44),
('Kasargode', 'Payyannur', 55);


insert into Users(user_name,password,role,is_Account_Locked) values('adwaith','adw@123','Motorist',false),('ridved','rid@123','Rider',false)



