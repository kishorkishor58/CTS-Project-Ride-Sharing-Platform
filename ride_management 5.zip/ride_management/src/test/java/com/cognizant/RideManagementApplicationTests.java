package com.cognizant;

import com.cognizant.RideManagementApplication;
import com.cognizant.controller.RideSchedulesController;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;


@SpringBootTest(classes = RideManagementApplication.class)
class RideManagementApplicationTests {

	@Autowired
	RideSchedulesController rideSchedulesController;
	@Test
	void contextLoads() {
		assertNotNull(rideSchedulesController);
	}

}
