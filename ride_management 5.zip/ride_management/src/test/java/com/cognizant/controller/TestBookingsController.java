package com.cognizant.controller;


import com.cognizant.dto.BookingsDTO;
import com.cognizant.service.BookingsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
class TestBookingsController {

    @InjectMocks
    BookingsController bookingsController;

    @Mock
    BookingsService bookingsService;

    @BeforeEach
    public void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getBookingId_Positive() {
        BookingsDTO bookingsDTO = new BookingsDTO();
        bookingsDTO.setId(1);

        when(bookingsService.insertBookings(any(BookingsDTO.class))).thenReturn(bookingsDTO);

        ResponseEntity<?> response = bookingsController.getBookingId(new BookingsDTO());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody());
    }

    @Test
    void getBookingId_Negative() {
        when(bookingsService.insertBookings(any(BookingsDTO.class))).thenThrow(new RuntimeException());

        try {
            bookingsController.getBookingId(new BookingsDTO());
        } catch (Exception e) {
            assertEquals(RuntimeException.class, e.getClass());
        }
    }

    @Test
    void testHandleValidationExceptions() {
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        ObjectError objectError1 = new FieldError("object", "field", "defaultMessage1");
        ObjectError objectError2 = new FieldError("object", "field", "defaultMessage2");

        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Arrays.asList(objectError1, objectError2));


        ResponseEntity<?> result = bookingsController.handleValidationExceptions(ex);

        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals(Arrays.asList("defaultMessage1", "defaultMessage2"), result.getBody());
    }
}

