package com.cognizant.controller;

import com.cognizant.dto.DistancesDTO;
import com.cognizant.service.DistancesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

class TestDistancesController {

    @InjectMocks
    DistancesController distancesController;

    @Mock
    DistancesService distancesService;

    @BeforeEach
    public void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAllDistances_Positive() {
        DistancesDTO distancesDTO1 = new DistancesDTO();
        DistancesDTO distancesDTO2 = new DistancesDTO();
        List<DistancesDTO> distancesDTOList = Arrays.asList(distancesDTO1, distancesDTO2);

        when(distancesService.getAllDistance()).thenReturn(distancesDTOList);

        List<DistancesDTO> response = distancesController.getAllDistances();

        assertEquals(2, response.size());
    }

    @Test
    void getAllDistances_Negative() {
        when(distancesService.getAllDistance()).thenThrow(new RuntimeException());

        try {
            distancesController.getAllDistances();
        } catch (Exception e) {
            assertEquals(RuntimeException.class, e.getClass());
        }
    }

}
