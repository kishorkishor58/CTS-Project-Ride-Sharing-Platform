package com.cognizant.controller;

import com.cognizant.dto.FareParametersDTO;
import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.exception.NoOfSeatsLimitExceedException;
import com.cognizant.exception.SameFromAndToPlaceException;
import com.cognizant.exception.VehicleNotApprovedException;
import com.cognizant.service.RideSchedulesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;


import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TestRideSchedulesController {

    @InjectMocks
    RideSchedulesController rideSchedulesController;

    @Mock
    RideSchedulesService rideSchedulesService;

    @BeforeEach
    public void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createNewRide_Positive() {
        RideSchedulesDTO rideSchedulesDTO = new RideSchedulesDTO();

        when(rideSchedulesService.insertRideSchedules(any(RideSchedulesDTO.class))).thenReturn(rideSchedulesDTO);

        ResponseEntity<?> response = rideSchedulesController.createNewRide(new RideSchedulesDTO());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(rideSchedulesDTO, response.getBody());
    }

    @Test
    void createNewRide_Negative_SameFromAndToPlaceException() {
        when(rideSchedulesService.insertRideSchedules(any(RideSchedulesDTO.class))).thenThrow(new SameFromAndToPlaceException("Same From and To Place"));

        ResponseEntity<?> response = rideSchedulesController.createNewRide(new RideSchedulesDTO());

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Same From and To Place", response.getBody());
    }

    @Test
    void createNewRide_Negative_VehicleNotApprovedException() {
        when(rideSchedulesService.insertRideSchedules(any(RideSchedulesDTO.class))).thenThrow(new VehicleNotApprovedException("Vehicle Not Approved"));

        ResponseEntity<?> response = rideSchedulesController.createNewRide(new RideSchedulesDTO());

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Vehicle Not Approved", response.getBody());
    }

    @Test
    void createNewRide_Negative_NoOfSeatsLimitExceedException() {
        when(rideSchedulesService.insertRideSchedules(any(RideSchedulesDTO.class))).thenThrow(new NoOfSeatsLimitExceedException("Number of Seats Limit Exceeded"));

        ResponseEntity<?> response = rideSchedulesController.createNewRide(new RideSchedulesDTO());

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Number of Seats Limit Exceeded", response.getBody());
    }

    @Test
    void calculateFare_Positive() {
        FareParametersDTO fareParametersDTO = new FareParametersDTO();

        when(rideSchedulesService.calculateFare(any(FareParametersDTO.class))).thenReturn(100);

        int fare = rideSchedulesController.calculateFare(new FareParametersDTO());

        assertEquals(100, fare);
    }

    @Test
    void calculateFare_Negative() {
        when(rideSchedulesService.calculateFare(any(FareParametersDTO.class))).thenThrow(new RuntimeException());

        try {
            rideSchedulesController.calculateFare(new FareParametersDTO());
        } catch (Exception e) {
            assertEquals(RuntimeException.class, e.getClass());
        }
    }

//    @Test
//    void searchRide_Positive() {
//        SearchCriteriaDTO searchCriteriaDTO = new SearchCriteriaDTO();
//        searchCriteriaDTO.setTo("Kannur");
//        searchCriteriaDTO.setFrom("Payyanur");
//        searchCriteriaDTO.setMaxPrice(400);
//        searchCriteriaDTO.setMinPrice(100);
//        searchCriteriaDTO.setAvailableSeats(2);
//
//        RideSchedulesDTO rideSchedulesDTO1 = new RideSchedulesDTO();
//        rideSchedulesDTO1.setRideFrom("Kannur");
//        rideSchedulesDTO1.setRideTo("Payyanur");
//        rideSchedulesDTO1.setRideFare(100);
//        rideSchedulesDTO1.setNoOfSeatsAvailable(3);
//        rideSchedulesDTO1.setIsApproved("approved");
//
//        RideSchedulesDTO rideSchedulesDTO2 = new RideSchedulesDTO();
//        rideSchedulesDTO2.setRideFrom("Kannur");
//        rideSchedulesDTO2.setRideTo("Payyanur");
//        rideSchedulesDTO2.setRideFare(110);
//        rideSchedulesDTO2.setNoOfSeatsAvailable(3);
//        rideSchedulesDTO2.setIsApproved("approved");
//
//        List<RideSchedulesDTO> rideSchedulesDTOList = Arrays.asList(rideSchedulesDTO1, rideSchedulesDTO2);
//
//        when(rideSchedulesService.searchRide(searchCriteriaDTO)).thenReturn(rideSchedulesDTOList);
//
//        List<RideSchedulesDTO> response = rideSchedulesController.searchRide("Kannur", "Payyanur", 50, 400, 2);
//
//        assertEquals(2, response.size());
//    }


    @Test
    void searchRide_Negative() {
        SearchCriteriaDTO searchCriteriaDTO = new SearchCriteriaDTO();
        searchCriteriaDTO.setTo("to");
        searchCriteriaDTO.setFrom("from");
        searchCriteriaDTO.setMaxPrice(100);
        searchCriteriaDTO.setMinPrice(50);
        searchCriteriaDTO.setAvailableSeats(2);

        when(rideSchedulesService.searchRide(searchCriteriaDTO)).thenThrow(new RuntimeException());

        try {
            rideSchedulesController.searchRide("to", "from", 50, 100, 2);
        } catch (Exception e) {
            assertEquals(RuntimeException.class, e.getClass());
        }
    }

    @Test
    void testHandleValidationExceptions() {
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        ObjectError objectError1 = new FieldError("object", "field", "defaultMessage1");
        ObjectError objectError2 = new FieldError("object", "field", "defaultMessage2");

        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Arrays.asList(objectError1, objectError2));


        ResponseEntity<?> result = rideSchedulesController.handleValidationExceptions(ex);

        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals(Arrays.asList("defaultMessage1", "defaultMessage2"), result.getBody());
    }

}
