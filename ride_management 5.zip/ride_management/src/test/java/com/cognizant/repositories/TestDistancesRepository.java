package com.cognizant.repositories;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.RideManagementApplication;
import com.cognizant.entity.Distances;


@DataJpaTest
@ContextConfiguration(classes = RideManagementApplication.class)
class TestDistancesRepository {
	@Autowired
	private DistancesRepository distancesRepository;

	@Autowired
	private TestEntityManager entityManager;

	@Test
	void testFindAllPositive() {
		Distances d = new Distances();

		d.setDistanceInKMS(38);
		d.setFrom("Kannur");
		d.setTo("Payyanur");
		entityManager.persist(d);
		Iterable<Distances> it = distancesRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}

	@Test
	void testFindByIdPositive() {
		Distances d = new Distances();

		d.setDistanceInKMS(38);
		d.setFrom("Kannur");
		d.setTo("Payyanur");
		int id = entityManager.persist(d).getId();
		Optional<Distances> it = distancesRepository.findById(id);
		assertTrue(it.isPresent());

	}

	@Test
	void testFindByIdNegative() {
		Optional<Distances> it = distancesRepository.findById(21);
		assertTrue(!it.isPresent());
	}

	@Test
	void testSavePositive() {
		Distances d = new Distances();

		d.setDistanceInKMS(38);
		d.setFrom("Kannur");
		d.setTo("Payyanur");
		int id = distancesRepository.save(d).getId();
		Optional<Distances> it = distancesRepository.findById(id);
		assertTrue(it.isPresent());

	}

	@Test
	void testDeletePositive() {
		Distances d = new Distances();

		d.setDistanceInKMS(38);
		d.setFrom("Kannur");
		d.setTo("Payyanur");
		entityManager.persist(d);
		distancesRepository.delete(d);
		Optional<Distances> it = distancesRepository.findById(21);
		assertTrue(!it.isPresent());
	}

	@Test
	void testCount() {
		Distances d = new Distances();

		d.setDistanceInKMS(38);
		d.setFrom("Kannur");
		d.setTo("Payyanur");
		entityManager.persist(d);
		long actualCount = distancesRepository.count();
		long expectedCount = 21;
		assertEquals(expectedCount, actualCount);
	}

}
