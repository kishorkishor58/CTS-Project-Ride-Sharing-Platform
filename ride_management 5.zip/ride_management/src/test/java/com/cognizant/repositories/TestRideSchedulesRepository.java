package com.cognizant.repositories;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.RideManagementApplication;
import com.cognizant.entity.RideSchedules;
import com.cognizant.repositories.RideSchedulesRepository;

@DataJpaTest
@ContextConfiguration(classes = RideManagementApplication.class)
class TestRideSchedulesRepository {

	@Autowired
	private RideSchedulesRepository rideScheduleRepository;
	@Autowired
	private TestEntityManager entityMangaer;

	@Test
	void testFindAllPositive() {

		RideSchedules rs = new RideSchedules();

		rs.setRideFrom("Kannur");
		rs.setRideTo("Payyannur");
		rs.setRideStartsOn(LocalDate.now());
		rs.setRideTime(LocalTime.now());
		rs.setRideFare(200);
		rs.setVehicleRegistrationNo("KL13AJ2913");
		rs.setMotoristUserId(2);
		rs.setNoOfSeatsAvailable(1);
		entityMangaer.persist(rs);
		Iterable<RideSchedules> it = rideScheduleRepository.findAll();
		assertTrue(it.iterator().hasNext());

	}

	@Test
	void testFindAllNegative() {

		Iterable<RideSchedules> it = rideScheduleRepository.findAll();
		assertTrue(!it.iterator().hasNext());

	}

	@Test
	void testFindByIdPositive() {
		RideSchedules rs = new RideSchedules();

		rs.setRideFrom("Kannur");
		rs.setRideTo("Payyannur");
		rs.setRideStartsOn(LocalDate.now());
		rs.setRideTime(LocalTime.now());
		rs.setRideFare(200);
		rs.setVehicleRegistrationNo("KL13AJ2913");
		rs.setMotoristUserId(2);
		rs.setNoOfSeatsAvailable(1);
		int id = entityMangaer.persist(rs).getId();
		Optional<RideSchedules> it = rideScheduleRepository.findById(id);
		assertTrue(it.isPresent());

	}

	@Test
	void testFindByIdNegative() {

		Optional<RideSchedules> it = rideScheduleRepository.findById(1);
		assertTrue(!it.isPresent());
	}

	@Test
	void testSavePositive() {

		RideSchedules rs = new RideSchedules();

		rs.setRideFrom("Kannur");
		rs.setRideTo("Payyannur");
		rs.setRideStartsOn(LocalDate.now());
		rs.setRideTime(LocalTime.now());
		rs.setRideFare(200);
		rs.setVehicleRegistrationNo("KL13AJ2913");
		rs.setMotoristUserId(2);
		rs.setNoOfSeatsAvailable(1);
		int id = rideScheduleRepository.save(rs).getId();
		Optional<RideSchedules> it = rideScheduleRepository.findById(id);
		assertTrue(it.isPresent());
	}

	@Test
	void testDeletePositive() {

		RideSchedules rs = new RideSchedules();

		rs.setRideFrom("Kannur");
		rs.setRideTo("Payyannur");
		rs.setRideStartsOn(LocalDate.now());
		rs.setRideTime(LocalTime.now());
		rs.setRideFare(200);
		rs.setVehicleRegistrationNo("KL13AJ2913");
		rs.setMotoristUserId(2);
		rs.setNoOfSeatsAvailable(1);
		entityMangaer.persist(rs);
		rideScheduleRepository.delete(rs);
		Optional<RideSchedules> it = rideScheduleRepository.findById(1);
		assertTrue(!it.isPresent());
	}

	@Test
	void testCount() {
		RideSchedules rs = new RideSchedules();

		rs.setRideFrom("Kannur");
		rs.setRideTo("Payyannur");
		rs.setRideStartsOn(LocalDate.now());
		rs.setRideTime(LocalTime.now());
		rs.setRideFare(200);
		rs.setVehicleRegistrationNo("KL13AJ2913");
		rs.setMotoristUserId(2);
		rs.setNoOfSeatsAvailable(1);
		entityMangaer.persist(rs);
		long actualCount = rideScheduleRepository.count();
		long expectedAccount = 1;
		assertEquals(expectedAccount, actualCount);
	}

}
