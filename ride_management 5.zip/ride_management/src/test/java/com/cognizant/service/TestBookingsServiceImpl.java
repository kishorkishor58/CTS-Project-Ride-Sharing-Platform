package com.cognizant.service;

import com.cognizant.dto.BookingsDTO;
import com.cognizant.entity.Bookings;
import com.cognizant.mapper.BookingsMapper;
import com.cognizant.repositories.BookingsRepository;
import com.cognizant.service.impl.BookingsServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

class TestBookingsServiceImpl {
    @Mock
    BookingsRepository bookingsRepository;
    @InjectMocks
    BookingsServiceImpl bookingsService;
    @Mock
    BookingsMapper bMapper;
    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception{
        MockitoAnnotations.openMocks(this);
    }

    @Test
     void insertBookings_Positive(){
        BookingsDTO bookingsDTO = new BookingsDTO();
        bookingsDTO.setBookedOn(LocalDate.parse("2024-03-28"));
        bookingsDTO.setRiderUserId(23);
        bookingsDTO.setNoOfSeats(2);
        bookingsDTO.setTotalAmount(100);
        bookingsDTO.setPaymentMode("upi");

        Bookings bookings = new Bookings();
        bookings.setBookedOn(LocalDate.parse("2024-03-28"));
        bookings.setRiderUserId(23);
        bookings.setNoOfSeats(2);
        bookings.setTotalAmount(100);
        bookings.setPaymentMode("upi");

        when(bMapper.toBookings(bookingsDTO)).thenReturn(bookings);

        Bookings createBooking = new Bookings();
        createBooking.setBookedOn(LocalDate.parse("2024-03-28"));
        createBooking.setRiderUserId(23);
        createBooking.setNoOfSeats(2);
        createBooking.setTotalAmount(100);
        createBooking.setPaymentMode("upi");

        when(bookingsRepository.save(bookings)).thenReturn(createBooking);

        BookingsDTO bookingsDTO1=new BookingsDTO();
        bookingsDTO1.setBookedOn(LocalDate.parse("2024-03-28"));
        bookingsDTO1.setRiderUserId(23);
        bookingsDTO1.setNoOfSeats(2);
        bookingsDTO1.setTotalAmount(100);
        bookingsDTO1.setPaymentMode("upi");

        when(bMapper.toBookingsdto(createBooking)).thenReturn(bookingsDTO1);
        BookingsDTO bookingsDTO2=bookingsService.insertBookings(bookingsDTO);

        assertEquals(createBooking.getRiderUserId(),bookingsDTO2.getRiderUserId());
    }

    @Test
    void insertBookings_Negative(){

        BookingsDTO bookingsDTO = new BookingsDTO();
        Bookings bookings = new Bookings();

        when(bMapper.toBookings(bookingsDTO)).thenReturn(bookings);

        Bookings createBooking = new Bookings();

        when(bookingsRepository.save(bookings)).thenReturn(createBooking);

        BookingsDTO bookingsDTO1=new BookingsDTO();


        when(bMapper.toBookingsdto(createBooking)).thenReturn(bookingsDTO1);
        BookingsDTO bookingsDTO2=bookingsService.insertBookings(bookingsDTO);

        assertEquals(null,bookingsDTO2.getRiderUserId());
        assertEquals(0,createBooking.getRiderUserId());



    }

}



