package com.cognizant.service;

import com.cognizant.dto.DistancesDTO;
import com.cognizant.entity.Distances;
import com.cognizant.mapper.DistanceMapper;
import com.cognizant.repositories.DistancesRepository;
import com.cognizant.service.impl.DistancesServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class TestDistancesServiceImpl {
    @Mock
    DistancesRepository distancesRepository;

    @Mock
    DistanceMapper distanceMapper;
    @InjectMocks
    DistancesServiceImpl distancesServiceImpl;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception{
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAllDistance_Positive(){
        List<Distances> dis = new ArrayList<>();
        Distances distances = new Distances();
        distances.setDistanceInKMS(38);
        distances.setFrom("Kannur");
        distances.setTo("Payyannur");
        dis.add(distances);

        when(distancesRepository.findAll()).thenReturn(dis);

        DistancesDTO distancesDTO = new DistancesDTO();
        distancesDTO.setDistanceInKMS(38);
        distancesDTO.setFrom("Kannur");
        distancesDTO.setTo("Payyannur");
        when(distanceMapper.toDistanceDTO(Mockito.any())).thenReturn(distancesDTO);
        List<DistancesDTO> distancesDTOList = distancesServiceImpl.getAllDistance();

        assertEquals(38,distancesDTOList.get(0).getDistanceInKMS());
    }

    @Test
    void getAllDistance_Negative(){
        List<Distances> dis = new ArrayList<>();
        Distances distances = new Distances();

        dis.add(distances);

        when(distancesRepository.findAll()).thenReturn(dis);
        DistancesDTO distancesDTO = new DistancesDTO();

        when(distanceMapper.toDistanceDTO(Mockito.any())).thenReturn(distancesDTO);
        List<DistancesDTO> distancesDTOList = distancesServiceImpl.getAllDistance();

        assertEquals(null,distancesDTOList.get(0).getDistanceInKMS());
    }

}
