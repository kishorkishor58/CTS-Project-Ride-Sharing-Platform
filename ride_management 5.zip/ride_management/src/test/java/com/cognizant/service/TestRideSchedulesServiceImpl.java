package com.cognizant.service;

import com.cognizant.dto.FareParametersDTO;
import com.cognizant.dto.RideSchedulesDTO;
import com.cognizant.dto.SearchCriteriaDTO;
import com.cognizant.entity.Distances;
import com.cognizant.entity.RideSchedules;
import com.cognizant.mapper.RideSchedulesMapper;
import com.cognizant.repositories.DistancesRepository;
import com.cognizant.repositories.RideSchedulesRepository;
import com.cognizant.service.impl.RideSchedulesServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class TestRideSchedulesServiceImpl {

    @Mock
    DistancesRepository distancesRepository;

    @Mock
    FareParametersDTO fareParameters;

    @Mock
    RideSchedulesRepository rideSchedulesRepository;
    @InjectMocks
    RideSchedulesServiceImpl rideSchedulesService;

    @Mock
    RideSchedulesMapper rsMapper;
    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() throws Exception{
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void insertRideSchedules_Positive(){
        Distances distances = new Distances();
        distances.setDistanceInKMS(38);
        distances.setFrom("Kannur");
        distances.setTo("Payyanur");
        when(distancesRepository.findByFromAndTo(distances.getFrom(), distances.getTo())).thenReturn(distances);

        RideSchedulesDTO rideSchedulesDTO = new RideSchedulesDTO();
        rideSchedulesDTO.setIsApproved("approved");
        rideSchedulesDTO.setRideFrom("Kannur");
        rideSchedulesDTO.setRideTo("Payyanur");
        rideSchedulesDTO.setRideStartsOn(LocalDate.now());
        rideSchedulesDTO.setRideTime(LocalTime.now());
        rideSchedulesDTO.setNoOfSeatsAvailable(3);

        RideSchedules rideSchedules = new RideSchedules();
        rideSchedules.setRideFrom("Kannur");
        rideSchedules.setRideTo("Payyanur");
        rideSchedules.setRideStartsOn(LocalDate.now());
        rideSchedules.setRideTime(LocalTime.now());
        rideSchedules.setNoOfSeatsAvailable(3);

        when(rsMapper.toRideSchedules(rideSchedulesDTO)).thenReturn(rideSchedules);

        RideSchedules createRideSchedules = new RideSchedules();
        createRideSchedules.setRideFrom("Kannur");
        createRideSchedules.setRideTo("Payyanur");
        createRideSchedules.setRideStartsOn(LocalDate.now());
        createRideSchedules.setRideTime(LocalTime.now());
        createRideSchedules.setNoOfSeatsAvailable(3);


        when(rideSchedulesRepository.save(rideSchedules)).thenReturn(createRideSchedules);

        RideSchedulesDTO rideSchedulesDTO1=new RideSchedulesDTO();
        rideSchedulesDTO1.setIsApproved("approved");
        rideSchedulesDTO1.setRideFrom("Kannur");
        rideSchedulesDTO1.setRideTo("Payyanur");
        rideSchedulesDTO1.setRideStartsOn(LocalDate.now());
        rideSchedulesDTO1.setRideTime(LocalTime.now());
        rideSchedulesDTO1.setNoOfSeatsAvailable(3);

        when(rsMapper.toRideSchedulesDTO(createRideSchedules)).thenReturn(rideSchedulesDTO1);

        RideSchedulesDTO rideSchedulesDTO2 = rideSchedulesService.insertRideSchedules(rideSchedulesDTO);

        assertEquals(createRideSchedules.getRideFrom(),rideSchedulesDTO2.getRideFrom());

    }
    @Test
    public void testInsertRideSchedules_Negative_SameFromAndToPlace() throws Exception{
    Distances distances = new Distances();
    distances.setDistanceInKMS(38);
    distances.setFrom("Kannur");
    distances.setTo("Payyanur");
    when(distancesRepository.findByFromAndTo(anyString(), anyString())).thenReturn(distances);

    RideSchedulesDTO rideSchedulesDTO = new RideSchedulesDTO();
    rideSchedulesDTO.setIsApproved("approved");
    rideSchedulesDTO.setRideFrom("Kannur");
    rideSchedulesDTO.setRideTo("Kannur");
    rideSchedulesDTO.setNoOfSeatsAvailable(3);

    RideSchedules rideSchedules = new RideSchedules();
    rideSchedules.setRideFrom("Kannur");
    rideSchedules.setRideTo("Kannur");
    rideSchedules.setNoOfSeatsAvailable(3);


    when(rsMapper.toRideSchedules(rideSchedulesDTO)).thenReturn(rideSchedules);

    RideSchedules createRideSchedules = new RideSchedules();
    createRideSchedules.setRideFrom("Kannur");
    createRideSchedules.setRideTo("Kannur");
    createRideSchedules.setNoOfSeatsAvailable(5);


    when(rideSchedulesRepository.save(any())).thenReturn(createRideSchedules);

    RideSchedulesDTO rideSchedulesDTO1 = new RideSchedulesDTO();
    rideSchedulesDTO1.setIsApproved("approved");
    rideSchedulesDTO1.setRideFrom("Kannur");
    rideSchedulesDTO1.setRideTo("Kannur");
    rideSchedulesDTO1.setNoOfSeatsAvailable(3);

    when(rsMapper.toRideSchedulesDTO(createRideSchedules)).thenReturn(rideSchedulesDTO);
    RideSchedulesDTO rideSchedulesDTO2 = null ;
    try {
        rideSchedulesDTO2 = rideSchedulesService.insertRideSchedules(rideSchedulesDTO);
    } catch (Exception e) {
        assertTrue(true);
    }
}

    @Test
    public void insertRideSchedules_Negative_VehicleNotApproved() throws Exception{
        Distances distances = new Distances();
        distances.setDistanceInKMS(38);
        distances.setFrom("Kannur");
        distances.setTo("Payyanur");
        when(distancesRepository.findByFromAndTo(anyString(), anyString())).thenReturn(distances);

        RideSchedulesDTO rideSchedulesDTO = new RideSchedulesDTO();
        rideSchedulesDTO.setIsApproved("rejected");
        rideSchedulesDTO.setRideFrom("Kannur");
        rideSchedulesDTO.setRideTo("Payyannur");
        rideSchedulesDTO.setNoOfSeatsAvailable(3);

        RideSchedules rideSchedules = new RideSchedules();
        rideSchedules.setRideFrom("Kannur");
        rideSchedules.setRideTo("Payyannur");
        rideSchedules.setNoOfSeatsAvailable(3);


        when(rsMapper.toRideSchedules(rideSchedulesDTO)).thenReturn(rideSchedules);

        RideSchedules createRideSchedules = new RideSchedules();
        createRideSchedules.setRideFrom("Kannur");
        createRideSchedules.setRideTo("Payyannur");
        createRideSchedules.setNoOfSeatsAvailable(3);


        when(rideSchedulesRepository.save(any())).thenReturn(createRideSchedules);

        RideSchedulesDTO rideSchedulesDTO1 = new RideSchedulesDTO();
        rideSchedulesDTO1.setIsApproved("rejected");
        rideSchedulesDTO1.setRideFrom("Kannur");
        rideSchedulesDTO1.setRideTo("Payyannur");
        rideSchedulesDTO1.setNoOfSeatsAvailable(3);

        when(rsMapper.toRideSchedulesDTO(createRideSchedules)).thenReturn(rideSchedulesDTO);
        RideSchedulesDTO rideSchedulesDTO2 = null ;
        try {
            rideSchedulesDTO2 = rideSchedulesService.insertRideSchedules(rideSchedulesDTO);
        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    public void insertRideSchedules_Negative_NoOfSeatsLimitExceed() throws Exception{
        Distances distances = new Distances();
        distances.setDistanceInKMS(38);
        distances.setFrom("Kannur");
        distances.setTo("Payyanur");
        when(distancesRepository.findByFromAndTo(anyString(), anyString())).thenReturn(distances);

        RideSchedulesDTO rideSchedulesDTO = new RideSchedulesDTO();
        rideSchedulesDTO.setIsApproved("approved");
        rideSchedulesDTO.setRideFrom("Kannur");
        rideSchedulesDTO.setRideTo("Payyannur");
        rideSchedulesDTO.setNoOfSeatsAvailable(5);

        RideSchedules rideSchedules = new RideSchedules();
        rideSchedules.setRideFrom("Kannur");
        rideSchedules.setRideTo("Payyannur");
        rideSchedules.setNoOfSeatsAvailable(5);


        when(rsMapper.toRideSchedules(rideSchedulesDTO)).thenReturn(rideSchedules);

        RideSchedules createRideSchedules = new RideSchedules();
        createRideSchedules.setRideFrom("Kannur");
        createRideSchedules.setRideTo("Payyannur");
        createRideSchedules.setNoOfSeatsAvailable(5);


        when(rideSchedulesRepository.save(any())).thenReturn(createRideSchedules);

        RideSchedulesDTO rideSchedulesDTO1 = new RideSchedulesDTO();
        rideSchedulesDTO1.setIsApproved("approved");
        rideSchedulesDTO1.setRideFrom("Kannur");
        rideSchedulesDTO1.setRideTo("Payyannur");
        rideSchedulesDTO1.setNoOfSeatsAvailable(5);

        when(rsMapper.toRideSchedulesDTO(createRideSchedules)).thenReturn(rideSchedulesDTO);
        RideSchedulesDTO rideSchedulesDTO2 = null ;
        try {
            rideSchedulesDTO2 = rideSchedulesService.insertRideSchedules(rideSchedulesDTO);
        } catch (Exception e) {
            assertTrue(true);
        }
    }


    @Test
     void searchRide_Positive(){

        SearchCriteriaDTO searchCriteriaDTO = new SearchCriteriaDTO();
        searchCriteriaDTO.setFrom("Kannur");
        searchCriteriaDTO.setTo("Payyanur");
        searchCriteriaDTO.setMinPrice(50);
        searchCriteriaDTO.setMaxPrice(150);
        searchCriteriaDTO.setAvailableSeats(2);

        ArrayList<RideSchedules> rideSchedulesArrayList = new ArrayList<>();
        RideSchedules rs1 = new RideSchedules();
        rs1.setRideFrom("Kannur");
        rs1.setRideTo("Payyanur");
        rs1.setRideFare(100);
        rs1.setNoOfSeatsAvailable(3);

        RideSchedules rs2 = new RideSchedules();
        rs2.setRideFrom("Kozhikode");
        rs2.setRideTo("Kannur");
        rs2.setRideFare(110);
        rs2.setNoOfSeatsAvailable(2);


        rideSchedulesArrayList.add(rs1);
        rideSchedulesArrayList.add(rs2);

        when(rideSchedulesRepository.findByRideFromAndRideTo(searchCriteriaDTO.getFrom(),searchCriteriaDTO.getTo())).thenReturn(rideSchedulesArrayList);

        List<RideSchedulesDTO> rideSchedulesDTOList = new ArrayList<>();
        RideSchedulesDTO rsDTO1= new RideSchedulesDTO();
        rsDTO1.setRideFrom("Kannur");
        rsDTO1.setRideTo("Payyanur");
        rsDTO1.setRideFare(100);
        rsDTO1.setNoOfSeatsAvailable(3);
        rsDTO1.setIsApproved("approved");

        RideSchedulesDTO rsDTO2=new RideSchedulesDTO();
        rsDTO2.setRideFrom("Kozhikode");
        rsDTO2.setRideTo("Kannur");
        rsDTO2.setRideFare(110);
        rsDTO2.setNoOfSeatsAvailable(2);
        rsDTO2.setIsApproved("approved");


        rideSchedulesDTOList.add(rsDTO2);

        when(rsMapper.toRideSchedulesDTO(rs1)).thenReturn(rsDTO1);
        rideSchedulesDTOList.add(rsDTO1);
        List<RideSchedulesDTO> rideSchedulesDTOList1 =rideSchedulesService.searchRide(searchCriteriaDTO);


        assertEquals(rideSchedulesDTOList1.size(),rideSchedulesArrayList.size());



    }

    @Test
    void searchRide_Negative(){

        SearchCriteriaDTO searchCriteriaDTO = new SearchCriteriaDTO();
        searchCriteriaDTO.setFrom("Kannur");
        searchCriteriaDTO.setTo("Payyanur");
        searchCriteriaDTO.setMinPrice(50);
        searchCriteriaDTO.setMaxPrice(150);
        searchCriteriaDTO.setAvailableSeats(2);

        ArrayList<RideSchedules> rideSchedulesArrayList = new ArrayList<>();
        RideSchedules rs1 = new RideSchedules();

        RideSchedules rs2 = new RideSchedules();



        //rideSchedulesArrayList.add(rs1);
        //rideSchedulesArrayList.add(rs2);

        when(rideSchedulesRepository.findByRideFromAndRideTo(searchCriteriaDTO.getFrom(),searchCriteriaDTO.getTo())).thenReturn(rideSchedulesArrayList);

        List<RideSchedulesDTO> rideSchedulesDTOList = new ArrayList<>();
        RideSchedulesDTO rsDTO1= new RideSchedulesDTO();


        RideSchedulesDTO rsDTO2=new RideSchedulesDTO();



        rideSchedulesDTOList.add(rsDTO2);

        when(rsMapper.toRideSchedulesDTO(rs1)).thenReturn(rsDTO1);
        rideSchedulesDTOList.add(rsDTO1);
        List<RideSchedulesDTO> rideSchedulesDTOList1 =rideSchedulesService.searchRide(searchCriteriaDTO);


        assertEquals(rideSchedulesDTOList1.size(),rideSchedulesArrayList.size());



    }

    @Test
     void calculateFare_Positive(){

        FareParametersDTO fareParametersDTO = new FareParametersDTO();

        when(fareParameters.getDistance()).thenReturn(38);
        fareParametersDTO.setDistance(fareParameters.getDistance());
        int fare=rideSchedulesService.calculateFare(fareParametersDTO);
        assertEquals(380,fare);

    }
    @Test
     void calculateFare_Negative(){

        FareParametersDTO fareParametersDTO = new FareParametersDTO();
        when(fareParameters.getDistance()).thenReturn(0);
        fareParametersDTO.setDistance(fareParameters.getDistance());
        int fare=rideSchedulesService.calculateFare(fareParametersDTO);
        assertEquals(0,fare);

    }


}
