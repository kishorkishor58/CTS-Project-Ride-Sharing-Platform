import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookRideComponent } from './book-ride/book-ride.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ScheduleRideComponent } from './schedule-ride/schedule-ride.component';
import { SearchRidesComponent } from './search-rides/search-rides.component';
import { AuthGuardmotoristService } from './service/auth-guardmotorist.service';
import { AuthGuardriderService } from './service/auth-guardrider.service';

const routes: Routes = [
  {path:'home',component: HomeComponent},
  {path:'createRide',component:ScheduleRideComponent,canActivate:[AuthGuardmotoristService]},
  {path:'search',component:SearchRidesComponent,canActivate:[AuthGuardriderService]},
  {path:'bookRide/:id',component:BookRideComponent,canActivate:[AuthGuardriderService]},
  {path:'login',component:LoginComponent},
  {path:'' , redirectTo: 'login', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
