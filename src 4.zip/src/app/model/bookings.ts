export class Bookings {

    id: number;
    bookedOn: Date;
    riderUserId: number;
    noOfSeats: number;
    totalAmount: number;
    paymentMode: string;
    rideSchedulesId: number;

}
