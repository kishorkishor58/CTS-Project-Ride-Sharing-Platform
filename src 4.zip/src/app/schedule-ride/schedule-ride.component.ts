import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Distances } from '../model/distances';
import { DistancesService } from '../service/distances.service';
import {FormGroup,FormControl, FormBuilder, Validators, AbstractControl} from '@angular/forms'
import { RideSchedulesService } from '../service/ride-schedules.service';

@Component({
  selector: 'app-schedule-ride',
  templateUrl: './schedule-ride.component.html',
  styleUrl: './schedule-ride.component.css'
})
export class ScheduleRideComponent implements OnInit{

 

  distances: Distances[] = [];
  distance: number = 0;
  rideFarVal:number;
  showRideFare:boolean;
  today: Date;
  minTime: string;

  fromDistances = new Set<string>();
  toDistances= new Set<string>();

  addRideScheduleForm!:FormGroup;
  rideScheduleId: number=0;

  constructor(private http: HttpClient, private distancesService: DistancesService,private rideSchedulesService: RideSchedulesService,
    private formBuilder: FormBuilder){
      this.today=new Date();
      const hours =this.today.getHours();
      const minutes =this.today.getMinutes();
  }

  ngOnInit() {
    this.showRideFare=true;
    this.distancesService.getAllDistances()
      .subscribe(responseData =>{
        this.distances=responseData;
        responseData.forEach((distance,i)=>{
          this.fromDistances.add(distance.from);
          this.toDistances.add(distance.to);
        })
      })

    this.addRideScheduleForm= this.formBuilder.group({
      'isApproved' : new FormControl(null,Validators.required),
      'distance':new FormControl(null,Validators.required),
      'rideFrom' : new FormControl(null,Validators.required),
      'rideTo' : new FormControl(null,Validators.required),
      'rideStartsOn' : new FormControl(null,Validators.required),
      'rideTime' : new FormControl(null,Validators.required),
      'rideFare' : new FormControl(null,Validators.required),
      'vehicleRegistrationNo' : new FormControl(null,[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern('[A-Za-z0-9]*'),this.nonNegative]),
      'motoristUserId' : new FormControl(null,[Validators.required,Validators.min(100),Validators.max(999),Validators.pattern('^[0-9]*$'),this.nonNegative]),
      'noOfSeatsAvailable' : new FormControl(null,[Validators.required,Validators.min(1),Validators.max(9),Validators.pattern('^[0-9]*$'),this.nonNegative])
    });

    this.addRideScheduleForm.get('rideTo').valueChanges.subscribe(value => {
      if (value === this.addRideScheduleForm.get('rideFrom').value) {
        this.addRideScheduleForm.get('rideFrom').reset();
      }
    });

    this.addRideScheduleForm.get('rideFrom').valueChanges.subscribe(value => {
      if (value === this.addRideScheduleForm.get('rideTo').value) {
        this.addRideScheduleForm.get('rideTo').reset();
      }
    });
    
    this.addRideScheduleForm.get('rideFrom').valueChanges.subscribe(()=>this.getDistanceAndCalculateFare());
    this.addRideScheduleForm.get('rideTo').valueChanges.subscribe(()=>this.getDistanceAndCalculateFare());
  }

  getDistanceAndCalculateFare(){
    const from = this.addRideScheduleForm.get('rideFrom').value;
    const to = this.addRideScheduleForm.get('rideTo').value;
    this.distances.forEach(element => {
       if(element.from===from && element.to===to){
        this.distance=element.distanceInKMS;
       }
         
       });
    this.addRideScheduleForm.patchValue({"distance":this.distance});
    const distance = this.addRideScheduleForm.get('distance').value;
    const distanceData = {"distance": distance};
    this.rideSchedulesService.getCalculatedFare(distanceData)

    .subscribe(responseData =>{
      this.rideFarVal=responseData;
      console.log("rideFar"+this.rideFarVal);
     this.addRideScheduleForm.get('rideFare').patchValue(this.rideFarVal);

    })
  }


  onSubmit(){
    this.rideSchedulesService.createRideSchedule(this.addRideScheduleForm.value)
    .subscribe({
    next:responseData=>{
      this.rideScheduleId=responseData.id;
      this.addRideScheduleForm.reset();
      this.addRideScheduleForm.get('distance').setValue('');
      this.showRideFare=false;
      let notificationBar = document.getElementById('notification-bar');
        if (notificationBar !== null) {
          
          setTimeout(() => {
            if (notificationBar !== null) {
              notificationBar.innerHTML = '';
            }
          }, 5000);
        }


        setTimeout(()=>{
       window.location.reload();
       },300); 
    
    },
    error: err => {
      console.log(err)
      let notificationBar = document.getElementById('notification-bar');
      if (notificationBar !== null) {
        let errorMessage = err.error;
        notificationBar.innerHTML = `<div class="alert alert-danger" role="alert">${errorMessage}</div>`;
        setTimeout(() => {
          if (notificationBar !== null) {
            notificationBar.innerHTML = '';
          }
        }, 5000);
      }
    }
    
  })
 

  }

  nonNegative(control: AbstractControl) {
    if (control.value < 0) {
      return { 'negative': true };
    }
    return null;
  }
    

  
  
}
