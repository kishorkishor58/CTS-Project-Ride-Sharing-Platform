import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Distances } from '../model/distances';
import { RideSchedules } from '../model/ride-schedules';
import { DistancesService } from '../service/distances.service';
import { RideSchedulesService } from '../service/ride-schedules.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-search-rides',
  templateUrl: './search-rides.component.html',
  styleUrl: './search-rides.component.css'
})
export class SearchRidesComponent implements OnInit{

  rideSchedules: RideSchedules[] = [];
  distances: Distances[];
  searchRideScheduleForm:FormGroup;


  fromDistances= new Set<String>;
  toDistances = new Set<String>;



  showTable: boolean =false;

  toggleTable(){
    this.showTable=true;
  }

  constructor(private router:Router,private http:HttpClient,private distancesService:DistancesService,private rideSchedulesService:RideSchedulesService){
    
  }

  ngOnInit() {

    this.distancesService.getAllDistances()
    .subscribe(responseData=>{
      this.distances=responseData;
      responseData.forEach((distance,i)=>{
        this.fromDistances.add(distance.from);
        this.toDistances.add(distance.to);
      })
    })

    this.searchRideScheduleForm=new FormGroup({
      'rideFrom':new FormControl(null,Validators.required),
      'rideTo':new FormControl(null,Validators.required),
      'minFare':new FormControl(null,[Validators.required,Validators.min(0),Validators.max(999)]),
      'maxFare':new FormControl(null,[Validators.required,Validators.min(0),Validators.max(999)]),
      'noOfSeatsAvailable':new FormControl(null,Validators.required)
    })

    this.searchRideScheduleForm.get('rideTo').valueChanges.subscribe(value => {
      if (value === this.searchRideScheduleForm.get('rideFrom').value) {
        this.searchRideScheduleForm.get('rideFrom').reset();
      }
    });

    this.searchRideScheduleForm.get('rideFrom').valueChanges.subscribe(value => {
      if (value === this.searchRideScheduleForm.get('rideTo').value) {
        this.searchRideScheduleForm.get('rideTo').reset();
      }
    });

  }


  onSearch(){
    console.log("Form Submitted")
    const values = this.searchRideScheduleForm.value;
    console.log(values)
    this.rideSchedulesService.getSearchRideSchedule(values.rideTo, values.rideFrom, values.minFare, values.maxFare, values.noOfSeatsAvailable)
    .subscribe((rideSchedules: RideSchedules[])  => {
      console.log(rideSchedules)
      this.rideSchedules = rideSchedules;
      this.showTable = true;
    });
  }
  OnBook(id:number){
    this.router.navigate(["/bookRide",id]);
  }
}


  
  
  

