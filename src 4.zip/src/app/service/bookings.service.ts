import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Bookings } from '../model/bookings';

@Injectable({
  providedIn: 'root'
})
export class BookingsService {

  

  constructor(private http:HttpClient) { }

  private addBookingsURL="http://localhost:8090/api/rides/book";

  public createBookings(bookings: Bookings){
    return this.http.post<number>(this.addBookingsURL,bookings);
  }
}
