import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Distances } from '../model/distances';

@Injectable({
  providedIn: 'root'
})
export class DistancesService {

  constructor(private http:HttpClient) { }

  private  retrieveDistancesURL="http://localhost:8090/api/distances"

  public getAllDistances(){
    return this.http.get<Distances[]>(this.retrieveDistancesURL);
  }


}
